<?php
require_once __DIR__ . 'db/connection.php'; // Ajuste o caminho conforme necessário

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recebendo dados do formulário
    $nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
    $formacao = filter_input(INPUT_POST, 'formacao', FILTER_SANITIZE_STRING);
    // Professores vem como string, aqui você pode adaptar para salvar relação em outra tabela

    if (!$nome || !$formacao) {
        die("Erro: Dados incompletos.");
    }

    try {
        $database = new Database();
        $conn = $database->getConnection();

        // Como seu banco tem uma tabela `disciplina` com campos: nome, duracao e nivel_necessario
        // Adaptarei para inserir nome e nivel_necessario (formacao)
        // O campo duracao não está no formulário, então usarei um valor padrão (ex: 40)

        $sql = "INSERT INTO disciplina (nome, duraçao, nivel_necessario) VALUES (:nome, :duracao, :nivel)";
        $stmt = $conn->prepare($sql);
        $stmt->bindValue(':nome', $nome);
        $stmt->bindValue(':duracao', 40, PDO::PARAM_INT); // valor fixo temporário
        $stmt->bindValue(':nivel', strtolower($formacao)); // ajustar para 'n1', 'n2' ou 'n3' conforme sua regra

        $stmt->execute();

        echo "Disciplina cadastrada com sucesso!";

        // Aqui você pode redirecionar para outra página, por exemplo:
        // header("Location: disciplinas.php");
        // exit();

    } catch (PDOException $e) {
        echo "Erro ao salvar disciplina: " . $e->getMessage();
    }
} else {
    echo "Método inválido.";
}
?>
