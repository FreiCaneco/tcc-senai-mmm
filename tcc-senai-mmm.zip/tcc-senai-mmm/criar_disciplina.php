<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="UTF-8" />  
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />  
    <title>Formulário de Cadastro</title>
    <link rel="stylesheet" href="css/bootstrap.css" />
    <link rel="stylesheet" href="css/styles.css" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <!-- Fonte -->
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;600&display=swap" rel="stylesheet" />
  </head>
  <body>
    <?php include "navbar.php" ?>

    <div class="container mt-5">
      <h1 class="mb-4">Nova Disciplina</h1>

      <form action="salvar_disciplina.php" method="POST">
        <fieldset>
          <legend>Preencha corretamente</legend>

          <!-- Nome-->
          <div class="row g-3 mb-4">
            <div class="col">
              <label for="nome" class="form-label">Nome</label>
              <input
                type="text"
                class="form-control"
                placeholder="Digite o nome da disciplina"
                name="nome"
                id="nome"
                required
              />
            </div>
          </div>

          <!-- Formação necessária -->
          <div class="row g-3 mb-4">
            <div class="col">
              <label for="formacao" class="form-label">Formação Necessária</label>
              <select id="formacao" name="formacao" class="form-select" required>
                <option selected disabled>Selecione a formação</option>
                <option value="n1">Nível 1</option>
                <option value="n2">Nível 2</option>
                <option value="n3">Nível 3</option>
              </select>
            </div>
          </div>

          <!-- Professores -->
          <div class="row g-3 mb-4">
            <div class="col">
              <label for="professores" class="form-label">Professores</label>
              <select id="professores" name="professores" class="form-select" required>
                <option selected disabled>Selecione</option>
                <option value="1">Professor 1</option>
                <option value="2">Professor 2</option>
                <option value="3">Professor 3</option>
                <option value="4">Professor 4</option>
                <option value="5">Professor 5</option>
                <option value="6">Professor 6</option>
              </select>
            </div>
          </div>

          <!-- Botões de ação -->
          <div class="mt-4">
            <button style="margin-right:320px; padding: 5px 50px;" type="submit" class="btn btn-primary">Salvar</button>
            <button style="padding: 5px 40px;" type="reset" class="btn btn-secondary">Cancelar</button>
          </div>
        </fieldset>
      </form>
    </div>
  </body>
</html>
