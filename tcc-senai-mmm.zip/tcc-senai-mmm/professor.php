<?php
require_once 'db/connection.php';  // Ajuste o caminho conforme seu projeto

$database = new Database();
$conn = $database->getConnection();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Lista de Professores</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
  <div class="container mt-5">
    <h1>Professores cadastrados</h1>
    <?php
    if ($conn) {
        $sql = "SELECT nome FROM professor";
        $stmt = $conn->prepare($sql);
        $stmt->execute();

        $professores = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($professores) {
            echo '<ul class="list-group">';
            foreach ($professores as $professor) {
                echo '<li class="list-group-item">' . htmlspecialchars($professor['nome']) . '</li>';
            }
            echo '</ul>';
        } else {
            echo '<div class="alert alert-info">Nenhum professor encontrado.</div>';
        }
    } else {
        echo '<div class="alert alert-danger">Falha na conexão com o banco de dados.</div>';
    }
    ?>
  </div>
</body>
</html>
